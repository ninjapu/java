import java.util.Scanner;

class stack {
    private int[] stack;  // Array to hold stack elements
    private int top;      // Points to the top element in the stack
    private static final int MAX_SIZE = 10;  // Maximum size of the stack

    // Constructor to initialize the stack
    public stack() {
        stack = new int[MAX_SIZE];
        top = -1;  // stack is initially empty
    }

    // Method to push an element into the stack
    public void push(int value) {
        if (top >= MAX_SIZE - 1) {
            System.out.println("stack Overflow! Cannot push " + value);
        } else {
            stack[++top] = value;
            System.out.println(value + " pushed into the stack.");
        }
    }

    // Method to pop an element from the stack
    public int pop() {
        if (top < 0) {
            System.out.println("stack Underflow! No elements to pop.");
            return -1;
        } else {
            int value = stack[top--];
            System.out.println(value + " popped from the stack.");
            return value;
        }
    }

    // Method to check if the stack is empty
    public boolean isEmpty() {
        return top == -1;
    }

    // Method to check the element at the top of the stack
    public int peek() {
        if (top < 0) {
            System.out.println("stack is empty.");
            return -1;
        } else {
            return stack[top];
        }
    }

    public static void main(String[] args) {
        stack stack = new stack();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number to push: ");
        int value = scanner.nextInt();
        stack.push(value);

        System.out.print("Enter a number to push: ");
        value = scanner.nextInt();
        stack.push(value);

        System.out.print("Enter a number to push: ");
        value = scanner.nextInt();
        stack.push(value);

        stack.pop();
        stack.pop();

        System.out.println("Top element is: " + stack.peek());

        stack.pop();
        stack.pop();

        scanner.close();
    }
}